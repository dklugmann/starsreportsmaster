<?
$apikey = '5b205e851feea';
$starspath = "http://www.myastrologycharts.com/astroservice/";
$enginepath = "http://www.myastrologycharts.com/";
$enginename = "engineservice.php";
?>
