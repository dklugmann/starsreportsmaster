<?
$apikey = '5848cf41a1d24';
$starspath = "http://www.myastrologycharts.com/astroservice/";
$enginepath = "http://www.myastrologycharts.com/";
$enginename = "engineservice.php";
?>
